﻿# lancer-tests.ps1
# Exécution de référence des 20 tests avec un affichage lisible dans PowerShell :
#  - console et JVM Maven en UTF-8 (accents et tirets affichés correctement) ;
#  - option -ntp : pas de lignes de progression des téléchargements ;
#  - le vrai résultat Maven est conservé (BUILD FAILURE si des tests échouent, code de sortie transmis).
# Utilisation (dans le dossier demo) :
#   powershell -ExecutionPolicy Bypass -File .\lancer-tests.ps1
# Arguments supplémentaires transmis à Maven, ex. :
#   powershell -ExecutionPolicy Bypass -File .\lancer-tests.ps1 "-Dselenium.cdp.avertissements=true"

chcp 65001 > $null
$utf8 = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8
$env:MAVEN_OPTS = "-Dfile.encoding=UTF-8 -Dsun.stdout.encoding=UTF-8 -Dsun.stderr.encoding=UTF-8"

# Information sur TC13 (aucune valeur affichée)
if ([string]::IsNullOrWhiteSpace($env:AFFARIYET_EMAIL) -or [string]::IsNullOrWhiteSpace($env:AFFARIYET_PASSWORD)) {
    Write-Host "Info : AFFARIYET_EMAIL / AFFARIYET_PASSWORD non définis -> TC13 (connexion valide) sera IGNORÉ."
} else {
    Write-Host "Info : identifiants de test détectés -> TC13 (connexion valide) sera exécuté."
}

Set-Location $PSScriptRoot
& mvn -ntp clean test @args
$code = $LASTEXITCODE
Write-Host ("Code de sortie Maven : {0} ({1})" -f $code, $(if ($code -eq 0) { "BUILD SUCCESS" } else { "BUILD FAILURE : voir le bilan ci-dessus et reports\rapport-execution.html" }))
exit $code
